package com.intix.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.intix.entity.StatusServers;
import org.glassfish.jersey.server.mvc.Viewable;


import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.intix.handlers.Files;
import com.intix.handlers.Updater;

@Path("intix")
public class UpdataStatus {
	
	Updater upd = new Updater();

	@GET
	@Path("/incrementStatus/{instance}")
	public Response IncrementStatus(@PathParam("instance") String instance) throws IOException {

		StatusServers currentStatus = Files.readObject("config.json");
		StatusServers update = new StatusServers();
		ObjectMapper mapper = new ObjectMapper();

		Boolean valid = ValidateResponse(instance);
		
		if (valid) {
			if (instance.toLowerCase().contains("imw")) {
				update.setImw(currentStatus.getImw() + 1);
				upd.runImwScheduler("imw");
			}
			if (instance.toLowerCase().contains("solr")) {
				update.setSolr(currentStatus.getSolr() + 1);
				upd.runSolrScheduler("solr");
			}
			if (instance.toLowerCase().contains("zk")) {
				update.setZk(currentStatus.getZk() + 1);
				upd.runZkScheduler("zk");
			}
		}
		else {
			update.setImw(currentStatus.getImw());
			update.setSolr(currentStatus.getSolr());
			update.setZk(currentStatus.getZk());
			return Response.status(200).entity("Input not valid").build();
		}

		String json = mapper.writeValueAsString(update);
		Files.writeObject(json.toString(),"config.json");
		return Response.status(200).entity(json.toString()).build();
	}
	
	@GET
	@Path("/decreaseStatus/{instance}")
	public Response DecreaseStatus(@PathParam("instance") String instance) throws IOException {

		StatusServers currentStatus = Files.readObject("config.json");
		StatusServers update = new StatusServers();
		ObjectMapper mapper = new ObjectMapper();

		Boolean valid = ValidateResponse(instance);
		Boolean startIMW = false;

		if (valid) {
			update.setZk(currentStatus.getZk());
			update.setImw(currentStatus.getImw());
			update.setSolr(currentStatus.getSolr());

			if (instance.toLowerCase().contains("imw") && currentStatus.getImw()!=0) {
					update.setImw(currentStatus.getImw() - 1);
			}
			if (instance.toLowerCase().contains("solr") && currentStatus.getSolr()!=0) {
				update.setSolr(currentStatus.getSolr() - 1);
			}
			if (instance.toLowerCase().contains("zk") && currentStatus.getZk()!=0) {
				update.setZk(currentStatus.getZk() - 1);
			}
			if (update.getImw()+update.getSolr()+update.getZk()==0) {
				startIMW = true;
				upd.stopImwScheduler();
				upd.stopSolrScheduler();
				upd.stopZkScheduler();
				System.out.println("We can start imw");
			}
			if (update.getImw()==0) {
				upd.stopImwScheduler();
			}
			if (update.getSolr()==0) {
				upd.stopSolrScheduler();
			}
			if (update.getZk()==0) {
				upd.stopZkScheduler();
			}
		}
		else {
			update.setImw(currentStatus.getImw());
			update.setSolr(currentStatus.getSolr());
			update.setZk(currentStatus.getZk());
			return Response.status(200).entity("Input not valid").build();
		}

		String json = mapper.writeValueAsString(update);
		Files.writeObject(json.toString(),"config.json");
		return Response.status(200).entity(json.toString()).build();
	}
	


	public boolean ValidateResponse(String u) {
		if (u.toLowerCase().matches("imw|solr|zk")) {
			return true;
		} else {
			return false;
		}
	}
}
