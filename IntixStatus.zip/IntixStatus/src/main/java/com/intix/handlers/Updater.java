package com.intix.handlers;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intix.entity.StatusServers;

public class Updater {

	StatusServers currentStatus = Files.readObject("time.json");
	ObjectMapper mapper = new ObjectMapper();

	public void exec(String type, Integer counter) {
		if (type == "imw") {
			currentStatus.setImwScheduler(String.valueOf(counter) + " minutes passed");
		}
		if (type == "solr") {
			currentStatus.setSolrScheduler(String.valueOf(counter) + " minutes passed");
		}
		if (type == "zk") {
			currentStatus.setZkScheduler(String.valueOf(counter) + " minutes passed");
		}
		String json = null;
		try {
			json = mapper.writeValueAsString(currentStatus);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		Files.writeObject(json.toString(),"time.json");
	}
	
	Timer timerSolr = new Timer();
	Timer timerImw = new Timer();
	Timer timerZk = new Timer();
	
	public void runSolrScheduler(String type) {
		timerSolr = new Timer();
		int begin = 0;
		int timeInterval = 60000;
		timerSolr.schedule(new TimerTask() {
			int counter = 0;

			@Override
			public void run() {
				// call the method
				exec(type,counter);
				counter++;
				if (counter >= 30) {
					timerSolr.cancel();
				}
			}
		}, begin, timeInterval);
	}
	
	public void stopSolrScheduler() {
		System.out.println("Solr timer stopped");
		currentStatus.setSolrScheduler("FINISHED");
		timerSolr.cancel();
		String json = null;
		try {
			json = mapper.writeValueAsString(currentStatus);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		Files.writeObject(json.toString(),"time.json");
	}
	
	public void runImwScheduler(String type) {
		timerImw = new Timer();
		int begin = 0;
		int timeInterval = 60000;
		timerImw.schedule(new TimerTask() {
			int counter = 0;

			@Override
			public void run() {
				// call the method
				exec(type,counter);
				counter++;
				if (counter >= 30) {
					timerImw.cancel();
				}
			}
		}, begin, timeInterval);
	}
	
	public void stopImwScheduler() {
		System.out.println("Imw timer stopped");
		currentStatus.setImwScheduler("FINISHED");
		timerImw.cancel();
		String json = null;
		try {
			json = mapper.writeValueAsString(currentStatus);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		Files.writeObject(json.toString(),"time.json");
	}
	
	public void runZkScheduler(String type) {
		timerZk = new Timer();
		int begin = 0;
		int timeInterval = 60000;
		timerZk.schedule(new TimerTask() {
			int counter = 0;

			@Override
			public void run() {
				// call the method
				exec(type,counter);
				counter++;
				if (counter >= 30) {
					timerZk.cancel();
				}
			}
		}, begin, timeInterval);
	}
	
	public void stopZkScheduler() throws JsonProcessingException {
		System.out.println("Zookeeper timer stopped");
		currentStatus.setZkScheduler("FINISHED");
		timerZk.cancel();
		String json = null;
		try {
			json = mapper.writeValueAsString(currentStatus);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		Files.writeObject(json.toString(),"time.json");
	}
}
