package com.intix.config;

import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.server.mvc.jsp.JspMvcFeature;

public class JerseyConfiguration extends ResourceConfig {

    public JerseyConfiguration() {
        packages("com.intix");
        //register(LoggingFilter.class);
        register(JspMvcFeature.class);
        register(MultiPartFeature.class);
        property(JspMvcFeature.TEMPLATE_BASE_PATH, "/templates");
    }
}