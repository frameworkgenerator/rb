package com.intix.views;

import java.io.File;

import com.intix.handlers.Files;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.intix.entity.StatusServers;
import org.glassfish.jersey.server.mvc.Viewable;


import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.intix.handlers.Updater;

@Path("/")
public class Home { 
    @GET
    @Path("overview")
    public String Test() {
		StatusServers currentStatus = Files.readObject("config.json");
		StatusServers currentTime = Files.readObject("time.json");
		if(currentTime.getSolrScheduler()==null) {currentTime.setSolrScheduler("--");}
		if(currentTime.getZkScheduler()==null) {currentTime.setZkScheduler("--");}
		if(currentTime.getImwScheduler()==null) {currentTime.setImwScheduler("--");}
		
		StatusServers object = new StatusServers();
		object.setImw(currentStatus.getImw());
		object.setImwScheduler(currentTime.getImwScheduler());
		object.setSolr(currentStatus.getSolr());
		object.setSolrScheduler(currentTime.getSolrScheduler());
		object.setZk(currentStatus.getZk());
		object.setZkScheduler(currentTime.getZkScheduler());

        return "<!DOCTYPE html>\r\n" + 
        		"<html>\r\n" + 
        		"<head>\r\n" + 
        		"<style>\r\n" + 
        		"table {\r\n" + 
        		"  font-family: arial, sans-serif;\r\n" + 
        		"  border-collapse: collapse;\r\n" + 
        		"  width: 100%;\r\n" + 
        		"}\r\n" + 
        		"\r\n" + 
        		"td, th {\r\n" + 
        		"  border: 1px solid #dddddd;\r\n" + 
        		"  text-align: left;\r\n" + 
        		"  padding: 8px;\r\n" + 
        		"}\r\n" + 
        		"\r\n" + 
        		"tr:nth-child(even) {\r\n" + 
        		"  background-color: #dddddd;\r\n" + 
        		"}\r\n" + 
        		"</style>\r\n" + 
        		"</head>\r\n" + 
        		"<body>\r\n" + 
        		"\r\n" + 
        		"<h2>Servers inactive</h2>\r\n" + 
        		"\r\n" + 
        		"<table>\r\n" + 
        		"  <tr>\r\n" + 
        		"    <th>Solr</th>\r\n" + 
        		"    <th>Time</th>\r\n" + 
        		"    <th>Zookeeper</th>\r\n" + 
        		"    <th>Time</th>\r\n" + 
        		"    <th>Imw</th>\r\n" + 
        		"    <th>Time</th>\r\n" + 
        		"  </tr>\r\n" + 
        		"  <tr>\r\n" + 
        		"    <td>" + object.getSolr() + "</td>\r\n" + 
        		"    <td>" + object.getSolrScheduler().toString() + "</td>\r\n" + 
        		"    <td>" + object.getZk() + "</td>\r\n" + 
        		"    <td>" + object.getZkScheduler().toString() + "</td>\r\n" + 
        		"    <td>" + object.getImw() + "</td>\r\n" + 
        		"    <td>" + object.getImwScheduler().toString() + "</td>\r\n" + 
        		"  </tr>\r\n" + 
        		"</table>\r\n" + 
        		"\r\n" + 
        		"</body>\r\n" + 
        		"</html>";
    }
}
