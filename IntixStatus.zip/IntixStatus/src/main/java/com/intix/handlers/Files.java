package com.intix.handlers;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.intix.entity.StatusServers;

public class Files {
	
	public static Object writeObject(String content, String name) {
		String directory = System.getProperty("user.home");
		String fileName = name;
		String absolutePath = directory + File.separator + fileName;

		// Write the content in file
		try (FileWriter fileWriter = new FileWriter(absolutePath)) {
			String fileContent = content;
			fileWriter.write(fileContent);
			fileWriter.close();
		} catch (IOException e) {
			// Cxception handling
		}

		return absolutePath;
	}

	public static StatusServers readObject(String name) {
		String directory = System.getProperty("user.home");
		String fileName = name;
		String absolutePath = directory + File.separator + fileName;
		StatusServers st = new StatusServers();

		// reading the content of file
		try (FileInputStream fileInputStream = new FileInputStream(absolutePath)) {
			st = new ObjectMapper().readValue(fileInputStream, StatusServers.class);
		} catch (FileNotFoundException e) {
			// exception handling
		} catch (IOException e) {
			// exception handling
		}
		return st;
	}
}
