package com.intix.entity;

import java.io.Serializable;

public class StatusServers implements Serializable{
	private int solr;
	private int zk;
	private int imw;
	private String solrScheduler;
	private String zkScheduler;
	private String imwScheduler;

	
	public int getImw() {
		return imw;
	}
	public void setImw(int imw) {
		this.imw = imw;
	}
	public int getZk() {
		return zk;
	}
	public void setZk(int zk) {
		this.zk = zk;
	}
	public int getSolr() {
		return solr;
	}
	public void setSolr(int solr) {
		this.solr = solr;
	}
	public String getSolrScheduler() {
		return solrScheduler;
	}
	public void setSolrScheduler(String solrScheduler) {
		this.solrScheduler = solrScheduler;
	}
	public String getZkScheduler() {
		return zkScheduler;
	}
	public void setZkScheduler(String zkScheduler) {
		this.zkScheduler = zkScheduler;
	}
	public String getImwScheduler() {
		return imwScheduler;
	}
	public void setImwScheduler(String imwScheduler) {
		this.imwScheduler = imwScheduler;
	}

	
}
